angular.module("myApp").controller("aboutController",aboutController)
function aboutController() {
    const vm= this;
    vm.about= "This is my bio"; }