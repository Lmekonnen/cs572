angular.module("jobSearching").controller("jobsController",jobsController)
function jobsController(jobFactory){
    const vm=this;
    vm.title="Job Searching App";
    jobFactory.getAllJobs().then(function(response){
        console.log(response);
        vm.jobs=response;
    })
    vm.addJob=function(){
        const data={
            title:vm.jobTitle,
            salary:vm.jobSalary,
            description:vm.jobDescription, 
            experience:vm.jobExperience,  
            skills:vm.jobSkills,
            postDate:vm.jobPostDate
        }
        if(vm.jobForm.$valid && vm.jobForm.$dirty){
            jobFactory.addOneJob(data).then(function(response){
                console.log(response);
            }
            )
        }
    }
    vm.deleteJob=function(id){
        jobFactory.deleteOneJob(id).then(function(reponse){
            console.log("game",id);
        })
    }
}